package net.mcreator.vizisvirusmod.item;

import net.mcreator.vizisvirusmod.init.VizisVirusModModTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;

public class RedItem extends Item {
   public RedItem() {
      super((new Properties()).m_41491_(VizisVirusModModTabs.TAB_VIRUSMOD).m_41487_(64).m_41497_(Rarity.COMMON));
   }
}
