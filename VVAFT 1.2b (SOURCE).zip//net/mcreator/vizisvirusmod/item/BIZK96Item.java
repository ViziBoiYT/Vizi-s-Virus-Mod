package net.mcreator.vizisvirusmod.item;

import net.mcreator.vizisvirusmod.init.VizisVirusModModTabs;
import net.mcreator.vizisvirusmod.procedures.BIZKUSEProcedure;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties.Builder;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;

public class BIZK96Item extends Item {
   public BIZK96Item() {
      super((new Properties()).m_41491_(VizisVirusModModTabs.TAB_VIRUSMOD).m_41487_(64).m_41497_(Rarity.COMMON).m_41489_((new Builder()).m_38760_(0).m_38758_(0.0F).m_38765_().m_38757_().m_38767_()));
   }

   public UseAnim m_6164_(ItemStack itemstack) {
      return UseAnim.DRINK;
   }

   public int m_8105_(ItemStack itemstack) {
      return 1;
   }

   public InteractionResultHolder<ItemStack> m_7203_(Level world, Player entity, InteractionHand hand) {
      InteractionResultHolder<ItemStack> ar = super.m_7203_(world, entity, hand);
      ItemStack itemstack = (ItemStack)ar.m_19095_();
      double x = entity.m_20185_();
      double y = entity.m_20186_();
      double z = entity.m_20189_();
      BIZKUSEProcedure.execute(world, entity);
      return ar;
   }
}
