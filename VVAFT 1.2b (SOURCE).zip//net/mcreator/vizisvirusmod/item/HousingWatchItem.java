package net.mcreator.vizisvirusmod.item;

import java.util.Collections;
import java.util.Map;
import java.util.function.Consumer;
import net.mcreator.vizisvirusmod.client.model.ModelSubject;
import net.mcreator.vizisvirusmod.init.VizisVirusModModTabs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.IItemRenderProperties;
import net.minecraftforge.registries.ForgeRegistries;

public abstract class HousingWatchItem extends ArmorItem {
   public HousingWatchItem(EquipmentSlot slot, Properties properties) {
      super(new ArmorMaterial() {
         public int m_7366_(EquipmentSlot slot) {
            return (new int[]{13, 15, 16, 11})[slot.m_20749_()] * 25;
         }

         public int m_7365_(EquipmentSlot slot) {
            return (new int[]{0, 0, 0, 0})[slot.m_20749_()];
         }

         public int m_6646_() {
            return 9;
         }

         public SoundEvent m_7344_() {
            return (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(""));
         }

         public Ingredient m_6230_() {
            return Ingredient.f_43901_;
         }

         public String m_6082_() {
            return "housing_watch";
         }

         public float m_6651_() {
            return 0.0F;
         }

         public float m_6649_() {
            return 0.0F;
         }
      }, slot, properties);
   }

   public static class Leggings extends HousingWatchItem {
      public Leggings() {
         super(EquipmentSlot.LEGS, (new Properties()).m_41491_(VizisVirusModModTabs.TAB_VIRUSMOD));
      }

      public void initializeClient(Consumer<IItemRenderProperties> consumer) {
         consumer.accept(new IItemRenderProperties() {
            // $FF: synthetic field
            final HousingWatchItem.Leggings this$0;

            {
               this.this$0 = this$0;
            }

            @OnlyIn(Dist.CLIENT)
            public HumanoidModel getArmorModel(LivingEntity living, ItemStack stack, EquipmentSlot slot, HumanoidModel defaultModel) {
               HumanoidModel armorModel = new HumanoidModel(new ModelPart(Collections.emptyList(), Map.of("left_leg", (new ModelSubject(Minecraft.m_91087_().m_167973_().m_171103_(ModelSubject.LAYER_LOCATION))).LeftLeg, "right_leg", (new ModelSubject(Minecraft.m_91087_().m_167973_().m_171103_(ModelSubject.LAYER_LOCATION))).RightLeg, "head", new ModelPart(Collections.emptyList(), Collections.emptyMap()), "hat", new ModelPart(Collections.emptyList(), Collections.emptyMap()), "body", new ModelPart(Collections.emptyList(), Collections.emptyMap()), "right_arm", new ModelPart(Collections.emptyList(), Collections.emptyMap()), "left_arm", new ModelPart(Collections.emptyList(), Collections.emptyMap()))));
               armorModel.f_102817_ = living.m_6144_();
               armorModel.f_102609_ = defaultModel.f_102609_;
               armorModel.f_102610_ = living.m_6162_();
               return armorModel;
            }
         });
      }

      public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
         return "vizis_virus_mod:textures/entities/housingwatch.png";
      }
   }

   public static class Chestplate extends HousingWatchItem {
      public Chestplate() {
         super(EquipmentSlot.CHEST, (new Properties()).m_41491_(VizisVirusModModTabs.TAB_VIRUSMOD));
      }

      public void initializeClient(Consumer<IItemRenderProperties> consumer) {
         consumer.accept(new IItemRenderProperties() {
            // $FF: synthetic field
            final HousingWatchItem.Chestplate this$0;

            {
               this.this$0 = this$0;
            }

            @OnlyIn(Dist.CLIENT)
            public HumanoidModel getArmorModel(LivingEntity living, ItemStack stack, EquipmentSlot slot, HumanoidModel defaultModel) {
               HumanoidModel armorModel = new HumanoidModel(new ModelPart(Collections.emptyList(), Map.of("body", (new ModelSubject(Minecraft.m_91087_().m_167973_().m_171103_(ModelSubject.LAYER_LOCATION))).Body, "left_arm", (new ModelSubject(Minecraft.m_91087_().m_167973_().m_171103_(ModelSubject.LAYER_LOCATION))).LeftArm, "right_arm", (new ModelSubject(Minecraft.m_91087_().m_167973_().m_171103_(ModelSubject.LAYER_LOCATION))).RightArm, "head", new ModelPart(Collections.emptyList(), Collections.emptyMap()), "hat", new ModelPart(Collections.emptyList(), Collections.emptyMap()), "right_leg", new ModelPart(Collections.emptyList(), Collections.emptyMap()), "left_leg", new ModelPart(Collections.emptyList(), Collections.emptyMap()))));
               armorModel.f_102817_ = living.m_6144_();
               armorModel.f_102609_ = defaultModel.f_102609_;
               armorModel.f_102610_ = living.m_6162_();
               return armorModel;
            }
         });
      }

      public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
         return "vizis_virus_mod:textures/entities/housingwatch.png";
      }
   }
}
