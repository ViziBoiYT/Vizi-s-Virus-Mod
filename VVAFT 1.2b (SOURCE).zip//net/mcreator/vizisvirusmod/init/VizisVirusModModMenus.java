package net.mcreator.vizisvirusmod.init;

import java.util.ArrayList;
import java.util.List;
import net.mcreator.vizisvirusmod.world.inventory.ConsoleguiMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.network.IContainerFactory;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class VizisVirusModModMenus {
   private static final List<MenuType<?>> REGISTRY = new ArrayList();
   public static final MenuType<ConsoleguiMenu> CONSOLEGUI = register("consolegui", (id, inv, extraData) -> {
      return new ConsoleguiMenu(id, inv, extraData);
   });

   private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
      MenuType<T> menuType = new MenuType(containerFactory);
      menuType.setRegistryName(registryname);
      REGISTRY.add(menuType);
      return menuType;
   }

   @SubscribeEvent
   public static void registerContainers(Register<MenuType<?>> event) {
      event.getRegistry().registerAll((MenuType[])REGISTRY.toArray(new MenuType[0]));
   }
}
