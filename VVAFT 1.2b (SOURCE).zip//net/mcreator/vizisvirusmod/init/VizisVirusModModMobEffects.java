package net.mcreator.vizisvirusmod.init;

import net.mcreator.vizisvirusmod.potion.AngerMobEffect;
import net.mcreator.vizisvirusmod.potion.CalmingMobEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class VizisVirusModModMobEffects {
   public static final DeferredRegister<MobEffect> REGISTRY;
   public static final RegistryObject<MobEffect> CALMING;
   public static final RegistryObject<MobEffect> ANGER;

   static {
      REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, "vizis_virus_mod");
      CALMING = REGISTRY.register("calming", () -> {
         return new CalmingMobEffect();
      });
      ANGER = REGISTRY.register("anger", () -> {
         return new AngerMobEffect();
      });
   }
}
