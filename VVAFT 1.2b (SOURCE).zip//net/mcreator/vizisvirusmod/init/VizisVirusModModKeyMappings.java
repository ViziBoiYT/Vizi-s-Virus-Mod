package net.mcreator.vizisvirusmod.init;

import net.mcreator.vizisvirusmod.VizisVirusModMod;
import net.mcreator.vizisvirusmod.network.AdrenalineRushMessage;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.client.event.InputEvent.KeyInputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@EventBusSubscriber(
   bus = Bus.MOD,
   value = {Dist.CLIENT}
)
public class VizisVirusModModKeyMappings {
   public static final KeyMapping ADRENALINE_RUSH = new KeyMapping("key.vizis_virus_mod.adrenaline_rush", 86, "key.categories.gameplay");

   @SubscribeEvent
   public static void registerKeyBindings(FMLClientSetupEvent event) {
      ClientRegistry.registerKeyBinding(ADRENALINE_RUSH);
   }

   @EventBusSubscriber({Dist.CLIENT})
   public static class KeyEventListener {
      @SubscribeEvent
      public static void onKeyInput(KeyInputEvent event) {
         if (Minecraft.m_91087_().f_91080_ == null && event.getKey() == VizisVirusModModKeyMappings.ADRENALINE_RUSH.getKey().m_84873_() && event.getAction() == 1) {
            VizisVirusModMod.PACKET_HANDLER.sendToServer(new AdrenalineRushMessage(0, 0));
            AdrenalineRushMessage.pressAction(Minecraft.m_91087_().f_91074_, 0, 0);
         }

      }
   }
}
