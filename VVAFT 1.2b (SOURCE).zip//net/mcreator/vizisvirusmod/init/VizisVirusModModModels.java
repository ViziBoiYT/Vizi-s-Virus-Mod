package net.mcreator.vizisvirusmod.init;

import net.mcreator.vizisvirusmod.client.model.ModelBCU;
import net.mcreator.vizisvirusmod.client.model.ModelCustomModel;
import net.mcreator.vizisvirusmod.client.model.ModelDocterv3;
import net.mcreator.vizisvirusmod.client.model.ModelSubject;
import net.mcreator.vizisvirusmod.client.model.Modeldocter;
import net.mcreator.vizisvirusmod.client.model.Modelsubjectguy;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(
   bus = Bus.MOD,
   value = {Dist.CLIENT}
)
public class VizisVirusModModModels {
   @SubscribeEvent
   public static void registerLayerDefinitions(RegisterLayerDefinitions event) {
      event.registerLayerDefinition(ModelCustomModel.LAYER_LOCATION, ModelCustomModel::createBodyLayer);
      event.registerLayerDefinition(ModelDocterv3.LAYER_LOCATION, ModelDocterv3::createBodyLayer);
      event.registerLayerDefinition(Modelsubjectguy.LAYER_LOCATION, Modelsubjectguy::createBodyLayer);
      event.registerLayerDefinition(ModelBCU.LAYER_LOCATION, ModelBCU::createBodyLayer);
      event.registerLayerDefinition(Modeldocter.LAYER_LOCATION, Modeldocter::createBodyLayer);
      event.registerLayerDefinition(ModelSubject.LAYER_LOCATION, ModelSubject::createBodyLayer);
   }
}
