package net.mcreator.vizisvirusmod.init;

import net.mcreator.vizisvirusmod.enchantment.InvulnerabilityEnchantment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class VizisVirusModModEnchantments {
   public static final DeferredRegister<Enchantment> REGISTRY;
   public static final RegistryObject<Enchantment> INVULNERABILITY;

   static {
      REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, "vizis_virus_mod");
      INVULNERABILITY = REGISTRY.register("invulnerability", () -> {
         return new InvulnerabilityEnchantment(new EquipmentSlot[0]);
      });
   }
}
