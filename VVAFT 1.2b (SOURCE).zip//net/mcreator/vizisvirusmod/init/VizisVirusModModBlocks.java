package net.mcreator.vizisvirusmod.init;

import net.mcreator.vizisvirusmod.block.ConsoleBlock;
import net.mcreator.vizisvirusmod.block.ConsoleOpenBlock;
import net.mcreator.vizisvirusmod.block.VendingBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class VizisVirusModModBlocks {
   public static final DeferredRegister<Block> REGISTRY;
   public static final RegistryObject<Block> CONSOLE;
   public static final RegistryObject<Block> VENDING;
   public static final RegistryObject<Block> CONSOLE_OPEN;

   static {
      REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, "vizis_virus_mod");
      CONSOLE = REGISTRY.register("console", () -> {
         return new ConsoleBlock();
      });
      VENDING = REGISTRY.register("vending", () -> {
         return new VendingBlock();
      });
      CONSOLE_OPEN = REGISTRY.register("console_open", () -> {
         return new ConsoleOpenBlock();
      });
   }

   @EventBusSubscriber(
      bus = Bus.MOD,
      value = {Dist.CLIENT}
   )
   public static class ClientSideHandler {
      @SubscribeEvent
      public static void clientSetup(FMLClientSetupEvent event) {
         VendingBlock.registerRenderLayer();
         ConsoleOpenBlock.registerRenderLayer();
      }
   }
}
