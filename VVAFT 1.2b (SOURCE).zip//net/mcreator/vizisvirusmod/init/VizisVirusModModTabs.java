package net.mcreator.vizisvirusmod.init;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class VizisVirusModModTabs {
   public static CreativeModeTab TAB_VIRUSMOD;

   public static void load() {
      TAB_VIRUSMOD = new CreativeModeTab("tabvirusmod") {
         public ItemStack m_6976_() {
            return new ItemStack((ItemLike)VizisVirusModModItems.BIAK_16.get());
         }

         @OnlyIn(Dist.CLIENT)
         public boolean hasSearchBar() {
            return false;
         }
      };
   }
}
