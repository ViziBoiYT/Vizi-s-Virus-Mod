package net.mcreator.vizisvirusmod.init;

import net.mcreator.vizisvirusmod.entity.ResearchSubjectEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class VizisVirusModModEntities {
   public static final DeferredRegister<EntityType<?>> REGISTRY;
   public static final RegistryObject<EntityType<ResearchSubjectEntity>> RESEARCH_SUBJECT;

   private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, Builder<T> entityTypeBuilder) {
      return REGISTRY.register(registryname, () -> {
         return entityTypeBuilder.m_20712_(registryname);
      });
   }

   @SubscribeEvent
   public static void init(FMLCommonSetupEvent event) {
      event.enqueueWork(() -> {
         ResearchSubjectEntity.init();
      });
   }

   @SubscribeEvent
   public static void registerAttributes(EntityAttributeCreationEvent event) {
      event.put((EntityType)RESEARCH_SUBJECT.get(), ResearchSubjectEntity.createAttributes().m_22265_());
   }

   static {
      REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, "vizis_virus_mod");
      RESEARCH_SUBJECT = register("research_subject", Builder.m_20704_(ResearchSubjectEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ResearchSubjectEntity::new).m_20699_(0.6F, 1.8F));
   }
}
