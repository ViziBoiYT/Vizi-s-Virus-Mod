package net.mcreator.vizisvirusmod.init;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class VizisVirusModModSounds {
   public static Map<ResourceLocation, SoundEvent> REGISTRY = new HashMap();

   @SubscribeEvent
   public static void registerSounds(Register<SoundEvent> event) {
      Iterator var1 = REGISTRY.entrySet().iterator();

      while(var1.hasNext()) {
         Entry<ResourceLocation, SoundEvent> sound = (Entry)var1.next();
         event.getRegistry().register((SoundEvent)((SoundEvent)sound.getValue()).setRegistryName((ResourceLocation)sound.getKey()));
      }

   }

   static {
      REGISTRY.put(new ResourceLocation("vizis_virus_mod", "swipe"), new SoundEvent(new ResourceLocation("vizis_virus_mod", "swipe")));
      REGISTRY.put(new ResourceLocation("vizis_virus_mod", "vendingmachinesound"), new SoundEvent(new ResourceLocation("vizis_virus_mod", "vendingmachinesound")));
      REGISTRY.put(new ResourceLocation("vizis_virus_mod", "shoot"), new SoundEvent(new ResourceLocation("vizis_virus_mod", "shoot")));
      REGISTRY.put(new ResourceLocation("vizis_virus_mod", "heartbeat"), new SoundEvent(new ResourceLocation("vizis_virus_mod", "heartbeat")));
   }
}
