package net.mcreator.vizisvirusmod.init;

import net.mcreator.vizisvirusmod.item.AdvancedMedicalItem;
import net.mcreator.vizisvirusmod.item.BIAK16Item;
import net.mcreator.vizisvirusmod.item.BIIR10Item;
import net.mcreator.vizisvirusmod.item.BIMK23Item;
import net.mcreator.vizisvirusmod.item.BISM22Item;
import net.mcreator.vizisvirusmod.item.BIZK96Item;
import net.mcreator.vizisvirusmod.item.BasicMedicalItem;
import net.mcreator.vizisvirusmod.item.BiohazardControlUnitItem;
import net.mcreator.vizisvirusmod.item.BlackItem;
import net.mcreator.vizisvirusmod.item.BlueItem;
import net.mcreator.vizisvirusmod.item.GreenItem;
import net.mcreator.vizisvirusmod.item.HousingWatchItem;
import net.mcreator.vizisvirusmod.item.MedicPackItem;
import net.mcreator.vizisvirusmod.item.MedicalItem;
import net.mcreator.vizisvirusmod.item.PieceOfUniformiumItem;
import net.mcreator.vizisvirusmod.item.RedItem;
import net.mcreator.vizisvirusmod.item.ResearcherItem;
import net.mcreator.vizisvirusmod.item.StaffPackItem;
import net.mcreator.vizisvirusmod.item.SubjectItem;
import net.mcreator.vizisvirusmod.item.SubjectPackItem;
import net.mcreator.vizisvirusmod.item.VioletItem;
import net.mcreator.vizisvirusmod.item.YellowItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class VizisVirusModModItems {
   public static final DeferredRegister<Item> REGISTRY;
   public static final RegistryObject<Item> BIIR_10;
   public static final RegistryObject<Item> BIAK_16;
   public static final RegistryObject<Item> CONSOLE;
   public static final RegistryObject<Item> YELLOW;
   public static final RegistryObject<Item> BLUE;
   public static final RegistryObject<Item> VIOLET;
   public static final RegistryObject<Item> GREEN;
   public static final RegistryObject<Item> RED;
   public static final RegistryObject<Item> BLACK;
   public static final RegistryObject<Item> VENDING;
   public static final RegistryObject<Item> BIZK_96;
   public static final RegistryObject<Item> MEDICAL_CHESTPLATE;
   public static final RegistryObject<Item> MEDICAL_LEGGINGS;
   public static final RegistryObject<Item> BISM_22;
   public static final RegistryObject<Item> CONSOLE_OPEN;
   public static final RegistryObject<Item> BIMK_23;
   public static final RegistryObject<Item> SUBJECT_CHESTPLATE;
   public static final RegistryObject<Item> SUBJECT_LEGGINGS;
   public static final RegistryObject<Item> HOUSING_WATCH_CHESTPLATE;
   public static final RegistryObject<Item> HOUSING_WATCH_LEGGINGS;
   public static final RegistryObject<Item> BASIC_MEDICAL_CHESTPLATE;
   public static final RegistryObject<Item> BASIC_MEDICAL_LEGGINGS;
   public static final RegistryObject<Item> SUBJECT_PACK;
   public static final RegistryObject<Item> MEDIC_PACK;
   public static final RegistryObject<Item> RESEARCH_SUBJECT_SPAWN_EGG;
   public static final RegistryObject<Item> ADVANCED_MEDICAL_CHESTPLATE;
   public static final RegistryObject<Item> ADVANCED_MEDICAL_LEGGINGS;
   public static final RegistryObject<Item> BIOHAZARD_CONTROL_UNIT_HELMET;
   public static final RegistryObject<Item> BIOHAZARD_CONTROL_UNIT_CHESTPLATE;
   public static final RegistryObject<Item> BIOHAZARD_CONTROL_UNIT_LEGGINGS;
   public static final RegistryObject<Item> PIECE_OF_UNIFORMIUM;
   public static final RegistryObject<Item> STAFF_PACK;
   public static final RegistryObject<Item> RESEARCHER_CHESTPLATE;
   public static final RegistryObject<Item> RESEARCHER_LEGGINGS;

   private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
      return REGISTRY.register(block.getId().m_135815_(), () -> {
         return new BlockItem((Block)block.get(), (new Properties()).m_41491_(tab));
      });
   }

   private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block, CreativeModeTab tab) {
      return REGISTRY.register(block.getId().m_135815_(), () -> {
         return new DoubleHighBlockItem((Block)block.get(), (new Properties()).m_41491_(tab));
      });
   }

   static {
      REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, "vizis_virus_mod");
      BIIR_10 = REGISTRY.register("biir_10", () -> {
         return new BIIR10Item();
      });
      BIAK_16 = REGISTRY.register("biak_16", () -> {
         return new BIAK16Item();
      });
      CONSOLE = doubleBlock(VizisVirusModModBlocks.CONSOLE, VizisVirusModModTabs.TAB_VIRUSMOD);
      YELLOW = REGISTRY.register("yellow", () -> {
         return new YellowItem();
      });
      BLUE = REGISTRY.register("blue", () -> {
         return new BlueItem();
      });
      VIOLET = REGISTRY.register("violet", () -> {
         return new VioletItem();
      });
      GREEN = REGISTRY.register("green", () -> {
         return new GreenItem();
      });
      RED = REGISTRY.register("red", () -> {
         return new RedItem();
      });
      BLACK = REGISTRY.register("black", () -> {
         return new BlackItem();
      });
      VENDING = block(VizisVirusModModBlocks.VENDING, VizisVirusModModTabs.TAB_VIRUSMOD);
      BIZK_96 = REGISTRY.register("bizk_96", () -> {
         return new BIZK96Item();
      });
      MEDICAL_CHESTPLATE = REGISTRY.register("medical_chestplate", () -> {
         return new MedicalItem.Chestplate();
      });
      MEDICAL_LEGGINGS = REGISTRY.register("medical_leggings", () -> {
         return new MedicalItem.Leggings();
      });
      BISM_22 = REGISTRY.register("bism_22", () -> {
         return new BISM22Item();
      });
      CONSOLE_OPEN = doubleBlock(VizisVirusModModBlocks.CONSOLE_OPEN, (CreativeModeTab)null);
      BIMK_23 = REGISTRY.register("bimk_23", () -> {
         return new BIMK23Item();
      });
      SUBJECT_CHESTPLATE = REGISTRY.register("subject_chestplate", () -> {
         return new SubjectItem.Chestplate();
      });
      SUBJECT_LEGGINGS = REGISTRY.register("subject_leggings", () -> {
         return new SubjectItem.Leggings();
      });
      HOUSING_WATCH_CHESTPLATE = REGISTRY.register("housing_watch_chestplate", () -> {
         return new HousingWatchItem.Chestplate();
      });
      HOUSING_WATCH_LEGGINGS = REGISTRY.register("housing_watch_leggings", () -> {
         return new HousingWatchItem.Leggings();
      });
      BASIC_MEDICAL_CHESTPLATE = REGISTRY.register("basic_medical_chestplate", () -> {
         return new BasicMedicalItem.Chestplate();
      });
      BASIC_MEDICAL_LEGGINGS = REGISTRY.register("basic_medical_leggings", () -> {
         return new BasicMedicalItem.Leggings();
      });
      SUBJECT_PACK = REGISTRY.register("subject_pack", () -> {
         return new SubjectPackItem();
      });
      MEDIC_PACK = REGISTRY.register("medic_pack", () -> {
         return new MedicPackItem();
      });
      RESEARCH_SUBJECT_SPAWN_EGG = REGISTRY.register("research_subject_spawn_egg", () -> {
         return new ForgeSpawnEggItem(VizisVirusModModEntities.RESEARCH_SUBJECT, -1, -1, (new Properties()).m_41491_(CreativeModeTab.f_40753_));
      });
      ADVANCED_MEDICAL_CHESTPLATE = REGISTRY.register("advanced_medical_chestplate", () -> {
         return new AdvancedMedicalItem.Chestplate();
      });
      ADVANCED_MEDICAL_LEGGINGS = REGISTRY.register("advanced_medical_leggings", () -> {
         return new AdvancedMedicalItem.Leggings();
      });
      BIOHAZARD_CONTROL_UNIT_HELMET = REGISTRY.register("biohazard_control_unit_helmet", () -> {
         return new BiohazardControlUnitItem.Helmet();
      });
      BIOHAZARD_CONTROL_UNIT_CHESTPLATE = REGISTRY.register("biohazard_control_unit_chestplate", () -> {
         return new BiohazardControlUnitItem.Chestplate();
      });
      BIOHAZARD_CONTROL_UNIT_LEGGINGS = REGISTRY.register("biohazard_control_unit_leggings", () -> {
         return new BiohazardControlUnitItem.Leggings();
      });
      PIECE_OF_UNIFORMIUM = REGISTRY.register("piece_of_uniformium", () -> {
         return new PieceOfUniformiumItem();
      });
      STAFF_PACK = REGISTRY.register("staff_pack", () -> {
         return new StaffPackItem();
      });
      RESEARCHER_CHESTPLATE = REGISTRY.register("researcher_chestplate", () -> {
         return new ResearcherItem.Chestplate();
      });
      RESEARCHER_LEGGINGS = REGISTRY.register("researcher_leggings", () -> {
         return new ResearcherItem.Leggings();
      });
   }
}
