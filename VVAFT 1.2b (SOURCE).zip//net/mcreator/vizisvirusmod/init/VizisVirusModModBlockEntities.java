package net.mcreator.vizisvirusmod.init;

import com.mojang.datafixers.types.Type;
import net.mcreator.vizisvirusmod.block.entity.ConsoleBlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntityType.BlockEntitySupplier;
import net.minecraft.world.level.block.entity.BlockEntityType.Builder;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class VizisVirusModModBlockEntities {
   public static final DeferredRegister<BlockEntityType<?>> REGISTRY;
   public static final RegistryObject<BlockEntityType<?>> CONSOLE;

   private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntitySupplier<?> supplier) {
      return REGISTRY.register(registryname, () -> {
         return Builder.m_155273_(supplier, new Block[]{(Block)block.get()}).m_58966_((Type)null);
      });
   }

   static {
      REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITIES, "vizis_virus_mod");
      CONSOLE = register("console", VizisVirusModModBlocks.CONSOLE, ConsoleBlockEntity::new);
   }
}
