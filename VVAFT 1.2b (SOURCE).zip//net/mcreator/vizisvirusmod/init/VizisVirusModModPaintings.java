package net.mcreator.vizisvirusmod.init;

import net.minecraft.world.entity.decoration.Motive;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class VizisVirusModModPaintings {
   @SubscribeEvent
   public static void registerMotives(Register<Motive> event) {
      event.getRegistry().register((Motive)(new Motive(16, 16)).setRegistryName("besafe"));
      event.getRegistry().register((Motive)(new Motive(16, 16)).setRegistryName("nerd"));
      event.getRegistry().register((Motive)(new Motive(16, 16)).setRegistryName("viz"));
   }
}
