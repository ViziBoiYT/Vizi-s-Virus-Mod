package net.mcreator.vizisvirusmod.procedures;

import net.mcreator.vizisvirusmod.init.VizisVirusModModBlocks;
import net.mcreator.vizisvirusmod.init.VizisVirusModModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

public class AuthProcedure {
   public static void execute(LevelAccessor world, final double x, final double y, final double z, Entity entity) {
      if (entity != null) {
         double previousRecipe = 0.0D;
         if (entity instanceof Player) {
            Player _playerHasItem = (Player)entity;
            if (_playerHasItem.m_150109_().m_36063_(new ItemStack((ItemLike)VizisVirusModModItems.BLUE.get()))) {
               world.m_7731_(new BlockPos(x, y, z), ((Block)VizisVirusModModBlocks.CONSOLE_OPEN.get()).m_49966_(), 3);
               world.m_7731_(new BlockPos(x, y + -1.0D, z), ((Block)VizisVirusModModBlocks.CONSOLE_OPEN.get()).m_49966_(), 3);
               if (world instanceof Level) {
                  Level _level = (Level)world;
                  if (!_level.m_5776_()) {
                     _level.m_5594_((Player)null, new BlockPos(x, y, z), (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("vizis_virus_mod:swipe")), SoundSource.BLOCKS, 1.0F, 1.0F);
                  } else {
                     _level.m_7785_(x, y, z, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("vizis_virus_mod:swipe")), SoundSource.BLOCKS, 1.0F, 1.0F, false);
                  }
               }

               ((<undefinedtype>)(new Object() {
                  private int ticks = 0;
                  private float waitTicks;
                  private LevelAccessor world;

                  public void start(LevelAccessor world, int waitTicks) {
                     this.waitTicks = (float)waitTicks;
                     MinecraftForge.EVENT_BUS.register(this);
                     this.world = world;
                  }

                  @SubscribeEvent
                  public void tick(ServerTickEvent event) {
                     if (event.phase == Phase.END) {
                        ++this.ticks;
                        if ((float)this.ticks >= this.waitTicks) {
                           this.run();
                        }
                     }

                  }

                  private void run() {
                     this.world.m_7731_(new BlockPos(x, y, z), ((Block)VizisVirusModModBlocks.CONSOLE.get()).m_49966_(), 3);
                     this.world.m_7731_(new BlockPos(x, y + -1.0D, z), ((Block)VizisVirusModModBlocks.CONSOLE.get()).m_49966_(), 3);
                     MinecraftForge.EVENT_BUS.unregister(this);
                  }
               })).start(world, 50);
            }
         }

      }
   }
}
