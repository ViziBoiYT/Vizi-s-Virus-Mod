package net.mcreator.vizisvirusmod.procedures;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class BIZKUSEProcedure {
   public static void execute(LevelAccessor world, final Entity entity) {
      if (entity != null) {
         LivingEntity _entity;
         if (entity instanceof LivingEntity) {
            _entity = (LivingEntity)entity;
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19604_, 200, 1, false, false));
         }

         if (entity instanceof LivingEntity) {
            _entity = (LivingEntity)entity;
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19610_, 200, 1, false, false));
         }

         ((<undefinedtype>)(new Object() {
            private int ticks = 0;
            private float waitTicks;
            private LevelAccessor world;

            public void start(LevelAccessor world, int waitTicks) {
               this.waitTicks = (float)waitTicks;
               MinecraftForge.EVENT_BUS.register(this);
               this.world = world;
            }

            @SubscribeEvent
            public void tick(ServerTickEvent event) {
               if (event.phase == Phase.END) {
                  ++this.ticks;
                  if ((float)this.ticks >= this.waitTicks) {
                     this.run();
                  }
               }

            }

            private void run() {
               if (entity instanceof LivingEntity) {
                  LivingEntity _entity = (LivingEntity)entity;
                  _entity.m_6469_((new DamageSource("virus")).m_19380_(), 99999.0F);
               }

               MinecraftForge.EVENT_BUS.unregister(this);
            }
         })).start(world, 200);
      }
   }
}
