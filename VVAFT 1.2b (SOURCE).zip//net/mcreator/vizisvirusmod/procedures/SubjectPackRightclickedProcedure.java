package net.mcreator.vizisvirusmod.procedures;

import java.util.Random;
import net.mcreator.vizisvirusmod.init.VizisVirusModModItems;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;

public class SubjectPackRightclickedProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity instanceof Player) {
            Player _player = (Player)entity;
            ItemStack _stktoremove = new ItemStack((ItemLike)VizisVirusModModItems.SUBJECT_PACK.get());
            _player.m_150109_().m_36022_((p) -> {
               return _stktoremove.m_41720_() == p.m_41720_();
            }, 1, _player.f_36095_.m_39730_());
         }

         Level _level;
         ItemEntity entityToSpawn;
         if (Mth.m_14072_(new Random(), 1, 8) == 1) {
            if (world instanceof Level) {
               _level = (Level)world;
               if (!_level.m_5776_()) {
                  entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.HOUSING_WATCH_CHESTPLATE.get()));
                  entityToSpawn.m_32010_(10);
                  _level.m_7967_(entityToSpawn);
               }
            }

            if (world instanceof Level) {
               _level = (Level)world;
               if (!_level.m_5776_()) {
                  entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.HOUSING_WATCH_LEGGINGS.get()));
                  entityToSpawn.m_32010_(10);
                  _level.m_7967_(entityToSpawn);
               }
            }
         } else {
            if (world instanceof Level) {
               _level = (Level)world;
               if (!_level.m_5776_()) {
                  entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.SUBJECT_CHESTPLATE.get()));
                  entityToSpawn.m_32010_(10);
                  _level.m_7967_(entityToSpawn);
               }
            }

            if (world instanceof Level) {
               _level = (Level)world;
               if (!_level.m_5776_()) {
                  entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.SUBJECT_LEGGINGS.get()));
                  entityToSpawn.m_32010_(10);
                  _level.m_7967_(entityToSpawn);
               }
            }
         }

      }
   }
}
