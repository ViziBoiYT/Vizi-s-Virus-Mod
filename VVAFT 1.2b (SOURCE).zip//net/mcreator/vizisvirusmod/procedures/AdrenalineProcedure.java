package net.mcreator.vizisvirusmod.procedures;

import net.mcreator.vizisvirusmod.init.VizisVirusModModMobEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

public class AdrenalineProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, final Entity entity) {
      if (entity != null) {
         int var10000;
         label59: {
            if (entity instanceof LivingEntity) {
               LivingEntity _livEnt = (LivingEntity)entity;
               if (_livEnt.m_21023_((MobEffect)VizisVirusModModMobEffects.ANGER.get())) {
                  var10000 = _livEnt.m_21124_((MobEffect)VizisVirusModModMobEffects.ANGER.get()).m_19557_();
                  break label59;
               }
            }

            var10000 = 0;
         }

         if (var10000 < 1) {
            label52: {
               if (entity instanceof LivingEntity) {
                  LivingEntity _livEnt = (LivingEntity)entity;
                  if (_livEnt.m_21023_((MobEffect)VizisVirusModModMobEffects.CALMING.get())) {
                     var10000 = _livEnt.m_21124_((MobEffect)VizisVirusModModMobEffects.CALMING.get()).m_19557_();
                     break label52;
                  }
               }

               var10000 = 0;
            }

            if (var10000 < 1) {
               if (entity instanceof Player) {
                  Player _player = (Player)entity;
                  if (!_player.f_19853_.m_5776_()) {
                     _player.m_5661_(new TextComponent("RUN"), true);
                  }
               }

               if (world instanceof Level) {
                  Level _level = (Level)world;
                  if (!_level.m_5776_()) {
                     _level.m_5594_((Player)null, new BlockPos(x, y, z), (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("vizis_virus_mod:heartbeat")), SoundSource.PLAYERS, 1.0F, 1.0F);
                  } else {
                     _level.m_7785_(x, y, z, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("vizis_virus_mod:heartbeat")), SoundSource.PLAYERS, 1.0F, 1.0F, false);
                  }
               }

               LivingEntity _entity;
               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance((MobEffect)VizisVirusModModMobEffects.ANGER.get(), 600, 1, false, false));
               }

               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance(MobEffects.f_19596_, 600, 1, true, false));
               }

               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance(MobEffects.f_19600_, 600, 1, true, false));
               }

               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance(MobEffects.f_19598_, 600, 1, true, false));
               }

               ((<undefinedtype>)(new Object() {
                  private int ticks = 0;
                  private float waitTicks;
                  private LevelAccessor world;

                  public void start(LevelAccessor world, int waitTicks) {
                     this.waitTicks = (float)waitTicks;
                     MinecraftForge.EVENT_BUS.register(this);
                     this.world = world;
                  }

                  @SubscribeEvent
                  public void tick(ServerTickEvent event) {
                     if (event.phase == Phase.END) {
                        ++this.ticks;
                        if ((float)this.ticks >= this.waitTicks) {
                           this.run();
                        }
                     }

                  }

                  private void run() {
                     LivingEntity _entity;
                     if (entity instanceof LivingEntity) {
                        _entity = (LivingEntity)entity;
                        _entity.m_7292_(new MobEffectInstance((MobEffect)VizisVirusModModMobEffects.CALMING.get(), 1200, 1, false, false));
                     }

                     if (entity instanceof LivingEntity) {
                        _entity = (LivingEntity)entity;
                        _entity.m_7292_(new MobEffectInstance(MobEffects.f_19613_, 1200, 1, true, false));
                     }

                     MinecraftForge.EVENT_BUS.unregister(this);
                  }
               })).start(world, 600);
            }
         }

      }
   }
}
