package net.mcreator.vizisvirusmod.procedures;

import java.util.Random;
import net.mcreator.vizisvirusmod.init.VizisVirusModModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.registries.ForgeRegistries;

public class VendProcedure {
   public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
      if (entity != null) {
         if (entity instanceof Player) {
            Player _playerHasItem = (Player)entity;
            if (_playerHasItem.m_150109_().m_36063_(new ItemStack(Items.f_42749_))) {
               if (entity instanceof Player) {
                  Player _player = (Player)entity;
                  ItemStack _stktoremove = new ItemStack(Items.f_42749_);
                  _player.m_150109_().m_36022_((p) -> {
                     return _stktoremove.m_41720_() == p.m_41720_();
                  }, 1, _player.f_36095_.m_39730_());
               }

               Level _level;
               if (world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     _level.m_5594_((Player)null, new BlockPos(x, y, z), (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.dispenser.fail")), SoundSource.BLOCKS, 1.0F, 1.5F);
                  } else {
                     _level.m_7785_(x, y, z, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.dispenser.fail")), SoundSource.BLOCKS, 1.0F, 1.5F, false);
                  }
               }

               if (world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     _level.m_5594_((Player)null, new BlockPos(x, y, z), (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("vizis_virus_mod:vendingmachinesound")), SoundSource.BLOCKS, 0.5F, 1.1F);
                  } else {
                     _level.m_7785_(x, y, z, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("vizis_virus_mod:vendingmachinesound")), SoundSource.BLOCKS, 0.5F, 1.1F, false);
                  }
               }

               ItemEntity entityToSpawn;
               if (Mth.m_14072_(new Random(), 1, 30) == 1 && world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.BIAK_16.get()));
                     entityToSpawn.m_32010_(10);
                     _level.m_7967_(entityToSpawn);
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 30) == 1 && world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.BIZK_96.get()));
                     entityToSpawn.m_32010_(10);
                     _level.m_7967_(entityToSpawn);
                  }
               }

               ItemEntity entityToSpawn;
               int index2;
               Level _level;
               if (Mth.m_14072_(new Random(), 1, 7) == 1) {
                  for(index2 = 0; index2 < Mth.m_14072_(new Random(), 1, 10); ++index2) {
                     if (world instanceof Level) {
                        _level = (Level)world;
                        if (!_level.m_5776_()) {
                           entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(Items.f_42688_));
                           entityToSpawn.m_32010_(10);
                           _level.m_7967_(entityToSpawn);
                        }
                     }
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 5) == 1) {
                  for(index2 = 0; index2 < Mth.m_14072_(new Random(), 1, 5); ++index2) {
                     if (world instanceof Level) {
                        _level = (Level)world;
                        if (!_level.m_5776_()) {
                           entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.f_50267_));
                           entityToSpawn.m_32010_(10);
                           _level.m_7967_(entityToSpawn);
                        }
                     }
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 15) == 1) {
                  for(index2 = 0; index2 < Mth.m_14072_(new Random(), 1, 3); ++index2) {
                     if (world instanceof Level) {
                        _level = (Level)world;
                        if (!_level.m_5776_()) {
                           entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(Items.f_42749_));
                           entityToSpawn.m_32010_(10);
                           _level.m_7967_(entityToSpawn);
                        }
                     }
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 54) == 1 && world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.YELLOW.get()));
                     entityToSpawn.m_32010_(10);
                     _level.m_7967_(entityToSpawn);
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 85) == 1 && world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.VIOLET.get()));
                     entityToSpawn.m_32010_(10);
                     _level.m_7967_(entityToSpawn);
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 75) == 1 && world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.BLUE.get()));
                     entityToSpawn.m_32010_(10);
                     _level.m_7967_(entityToSpawn);
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 125) == 1 && world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.GREEN.get()));
                     entityToSpawn.m_32010_(10);
                     _level.m_7967_(entityToSpawn);
                  }
               }

               if (Mth.m_14072_(new Random(), 1, 150) == 1 && world instanceof Level) {
                  _level = (Level)world;
                  if (!_level.m_5776_()) {
                     entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack((ItemLike)VizisVirusModModItems.BLACK.get()));
                     entityToSpawn.m_32010_(10);
                     _level.m_7967_(entityToSpawn);
                  }
               }
            }
         }

      }
   }
}
