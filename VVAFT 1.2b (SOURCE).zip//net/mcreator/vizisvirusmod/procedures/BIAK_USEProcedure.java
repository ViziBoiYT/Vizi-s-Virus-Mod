package net.mcreator.vizisvirusmod.procedures;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class BIAK_USEProcedure {
   public static void execute(LevelAccessor world, final Entity entity) {
      if (entity != null) {
         if (entity instanceof LivingEntity) {
            LivingEntity _entity = (LivingEntity)entity;
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19604_, 100, 1, false, false));
         }

         ((<undefinedtype>)(new Object() {
            private int ticks = 0;
            private float waitTicks;
            private LevelAccessor world;

            public void start(LevelAccessor world, int waitTicks) {
               this.waitTicks = (float)waitTicks;
               MinecraftForge.EVENT_BUS.register(this);
               this.world = world;
            }

            @SubscribeEvent
            public void tick(ServerTickEvent event) {
               if (event.phase == Phase.END) {
                  ++this.ticks;
                  if ((float)this.ticks >= this.waitTicks) {
                     this.run();
                  }
               }

            }

            private void run() {
               LivingEntity _entity;
               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance(MobEffects.f_19597_, 6000, 2, false, false));
               }

               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance(MobEffects.f_19604_, 6000, 0, false, false));
               }

               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance(MobEffects.f_19613_, 6000, 5, false, false));
               }

               if (entity instanceof LivingEntity) {
                  _entity = (LivingEntity)entity;
                  _entity.m_7292_(new MobEffectInstance(MobEffects.f_19599_, 6000, 5, false, false));
               }

               MinecraftForge.EVENT_BUS.unregister(this);
            }
         })).start(world, 20);
      }
   }
}
