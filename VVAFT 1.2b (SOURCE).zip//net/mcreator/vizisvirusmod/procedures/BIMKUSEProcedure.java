package net.mcreator.vizisvirusmod.procedures;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class BIMKUSEProcedure {
   public static void execute(Entity entity) {
      if (entity != null) {
         LivingEntity _entity;
         if (entity instanceof LivingEntity) {
            _entity = (LivingEntity)entity;
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19604_, 999999999, 1, false, false));
         }

         if (entity instanceof LivingEntity) {
            _entity = (LivingEntity)entity;
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19615_, 999999999, 2, false, false));
         }

         if (entity instanceof LivingEntity) {
            _entity = (LivingEntity)entity;
            _entity.m_7292_(new MobEffectInstance(MobEffects.f_19599_, 999999999, 254, false, false));
         }

      }
   }
}
