package net.mcreator.vizisvirusmod.world.inventory;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.mcreator.vizisvirusmod.init.VizisVirusModModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.level.Level;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;

public class ConsoleguiMenu extends AbstractContainerMenu implements Supplier<Map<Integer, Slot>> {
   public static final HashMap<String, Object> guistate = new HashMap();
   public final Level world;
   public final Player entity;
   public int x;
   public int y;
   public int z;
   private IItemHandler internal;
   private final Map<Integer, Slot> customSlots = new HashMap();
   private boolean bound = false;

   public ConsoleguiMenu(int id, Inventory inv, FriendlyByteBuf extraData) {
      super(VizisVirusModModMenus.CONSOLEGUI, id);
      this.entity = inv.f_35978_;
      this.world = inv.f_35978_.f_19853_;
      this.internal = new ItemStackHandler(0);
      BlockPos pos = null;
      if (extraData != null) {
         pos = extraData.m_130135_();
         this.x = pos.m_123341_();
         this.y = pos.m_123342_();
         this.z = pos.m_123343_();
      }

   }

   public boolean m_6875_(Player player) {
      return true;
   }

   public Map<Integer, Slot> get() {
      return this.customSlots;
   }
}
