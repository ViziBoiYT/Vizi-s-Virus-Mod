package net.mcreator.vizisvirusmod.network;

import java.util.function.Supplier;
import net.mcreator.vizisvirusmod.VizisVirusModMod;
import net.mcreator.vizisvirusmod.procedures.AdrenalineProcedure;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.network.NetworkEvent.Context;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class AdrenalineRushMessage {
   int type;
   int pressedms;

   public AdrenalineRushMessage(int type, int pressedms) {
      this.type = type;
      this.pressedms = pressedms;
   }

   public AdrenalineRushMessage(FriendlyByteBuf buffer) {
      this.type = buffer.readInt();
      this.pressedms = buffer.readInt();
   }

   public static void buffer(AdrenalineRushMessage message, FriendlyByteBuf buffer) {
      buffer.writeInt(message.type);
      buffer.writeInt(message.pressedms);
   }

   public static void handler(AdrenalineRushMessage message, Supplier<Context> contextSupplier) {
      Context context = (Context)contextSupplier.get();
      context.enqueueWork(() -> {
         pressAction(context.getSender(), message.type, message.pressedms);
      });
      context.setPacketHandled(true);
   }

   public static void pressAction(Player entity, int type, int pressedms) {
      Level world = entity.f_19853_;
      double x = entity.m_20185_();
      double y = entity.m_20186_();
      double z = entity.m_20189_();
      if (world.m_46805_(entity.m_142538_())) {
         if (type == 0) {
            AdrenalineProcedure.execute(world, x, y, z, entity);
         }

      }
   }

   @SubscribeEvent
   public static void registerMessage(FMLCommonSetupEvent event) {
      VizisVirusModMod.addNetworkMessage(AdrenalineRushMessage.class, AdrenalineRushMessage::buffer, AdrenalineRushMessage::new, AdrenalineRushMessage::handler);
   }
}
