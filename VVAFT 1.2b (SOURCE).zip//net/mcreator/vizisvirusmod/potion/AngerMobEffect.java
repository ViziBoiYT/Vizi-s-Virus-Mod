package net.mcreator.vizisvirusmod.potion;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

public class AngerMobEffect extends MobEffect {
   public AngerMobEffect() {
      super(MobEffectCategory.HARMFUL, -52429);
   }

   public String m_19481_() {
      return "effect.vizis_virus_mod.anger";
   }

   public boolean m_6584_(int duration, int amplifier) {
      return true;
   }
}
