package net.mcreator.vizisvirusmod.potion;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

public class CalmingMobEffect extends MobEffect {
   public CalmingMobEffect() {
      super(MobEffectCategory.NEUTRAL, -13369396);
   }

   public String m_19481_() {
      return "effect.vizis_virus_mod.calming";
   }

   public boolean m_6584_(int duration, int amplifier) {
      return true;
   }
}
