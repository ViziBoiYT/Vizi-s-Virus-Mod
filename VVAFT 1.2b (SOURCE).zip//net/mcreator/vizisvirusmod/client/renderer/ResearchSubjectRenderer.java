package net.mcreator.vizisvirusmod.client.renderer;

import net.mcreator.vizisvirusmod.client.model.Modelsubjectguy;
import net.mcreator.vizisvirusmod.entity.ResearchSubjectEntity;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;

public class ResearchSubjectRenderer extends MobRenderer<ResearchSubjectEntity, Modelsubjectguy<ResearchSubjectEntity>> {
   public ResearchSubjectRenderer(Context context) {
      super(context, new Modelsubjectguy(context.m_174023_(Modelsubjectguy.LAYER_LOCATION)), 0.5F);
   }

   public ResourceLocation getTextureLocation(ResearchSubjectEntity entity) {
      return new ResourceLocation("vizis_virus_mod:textures/entities/subjectguy.png");
   }
}
