package net.mcreator.vizisvirusmod.block;

import java.util.Collections;
import java.util.List;
import net.mcreator.vizisvirusmod.init.VizisVirusModModBlocks;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.storage.loot.LootContext.Builder;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class ConsoleOpenBlock extends DoorBlock {
   public ConsoleOpenBlock() {
      super(Properties.m_60939_(Material.f_76279_).m_60918_(SoundType.f_56743_).m_60913_(1.0F, 10.0F).m_60955_().m_60924_((bs, br, bp) -> {
         return false;
      }));
   }

   public int m_7753_(BlockState state, BlockGetter worldIn, BlockPos pos) {
      return 0;
   }

   public List<ItemStack> m_7381_(BlockState state, Builder builder) {
      if (state.m_61143_(BlockStateProperties.f_61401_) != DoubleBlockHalf.LOWER) {
         return Collections.emptyList();
      } else {
         List<ItemStack> dropsOriginal = super.m_7381_(state, builder);
         return !dropsOriginal.isEmpty() ? dropsOriginal : Collections.singletonList(new ItemStack(this, 1));
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static void registerRenderLayer() {
      ItemBlockRenderTypes.setRenderLayer((Block)VizisVirusModModBlocks.CONSOLE_OPEN.get(), (renderType) -> {
         return renderType == RenderType.m_110466_();
      });
   }
}
